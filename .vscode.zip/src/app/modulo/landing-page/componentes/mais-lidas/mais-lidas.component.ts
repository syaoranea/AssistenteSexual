import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mais-lidas',
  templateUrl: './mais-lidas.component.html',
  styleUrls: ['./mais-lidas.component.scss']
})
export class MaisLidasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
